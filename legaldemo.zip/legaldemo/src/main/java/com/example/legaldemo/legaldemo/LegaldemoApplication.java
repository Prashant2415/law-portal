package com.example.legaldemo.legaldemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LegaldemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(LegaldemoApplication.class, args);
	}

}
